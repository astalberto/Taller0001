/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete02;

/**
 *
 * @author utpl
 */
public class Pension {

    private String nombre;
    private String apellido;
    private String cedulaRepresentante;
    private double valorPension;
    private double porcentajeIva;
    private double valorTotal;
    private int mesPension;

    public Pension() {
        nombre = "Estefania";
        apellido = "Gomes";
        cedulaRepresentante = "1100840032";
        valorPension = 350;
        porcentajeIva = 12;
        mesPension = 5;
    }

    public Pension(String n, String a, String c, double v, double p, int mes) {
        nombre = n;
        apellido = a;
        cedulaRepresentante = c;
        valorPension = v;
        porcentajeIva = p;
        mesPension = mes;
    }

    public void establecerNombre(String x) {
        nombre = x;
    }

    public void establecerApellido(String x) {
        apellido = x;
    }

    public void establecerCedulaRepresentante(String x) {
        cedulaRepresentante = x;
    }

    public void establecerValorPension(double n) {
        valorPension = n;
    }

    public void establecerPorcentajeIva(double n) {
        porcentajeIva = n;
    }

    public void establecerMesPension(int n) {
        mesPension = n;
    }

    public void calcularValorTotal() {
        valorTotal = valorPension + (((valorPension * porcentajeIva) / 100));
    }

    public String obtenerNombre() {
        return nombre;
    }

    public String obtenerApellido() {
        return apellido;
    }

    public String obtenerCedulaRepresentante() {
        return cedulaRepresentante;
    }

    public double obtenerValorPension() {
        return valorPension;
    }

    public double obtenerPorcentajeIva() {
        return porcentajeIva;
    }

    public double obtenerValorTotal() {
        return valorTotal;
    }

    public int obtenerMesPension() {
        return mesPension;
    }

    @Override
    public String toString() {
        String cadena = String.format("""
                                      ----------------------------
                                      Pension
                                      Nombres: %s %s                                    
                                      Cedula del Representante: %s
                                      Valor de la Pension: %.2f
                                      Porcentaje de Iva: %.0f
                                      Valor Total: %.2f
                                      Mes de la Pension: %d
                                      ----------------------------\n""",
                nombre,
                apellido,
                cedulaRepresentante,
                valorPension,
                porcentajeIva,
                valorTotal,
                mesPension
        );
        return cadena;
    }
}
