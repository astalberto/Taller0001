/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paquete01;

import paquete02.Pension;

/**
 *
 * @author utpl
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pension p1 = new Pension();
        p1.calcularValorTotal();
        System.out.printf("%s", p1);
        Pension p2 = new Pension("Mario", "Guarinda", "1801613230", 150, 15, 4);
        p2.calcularValorTotal();
        System.out.printf("%s", p2);
    }

}
