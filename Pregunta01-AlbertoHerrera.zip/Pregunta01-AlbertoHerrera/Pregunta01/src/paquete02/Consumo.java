/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete02;

/**
 *
 * @author utpl
 */
public class Consumo {

    private String cedula;
    private String detalleCompra;
    private String userName;
    private double valorCompra;
    private int mesesDiferir;
    private double valorFinal;
    private double porcentajeInteres;

    public Consumo(String c, String detalleC, String userN, double valorC, int meses, double interes) {
        cedula = c;
        detalleCompra = detalleC;
        userName = userN;
        valorCompra = valorC;
        mesesDiferir = meses;
        porcentajeInteres = interes;
    }

    public Consumo(String c, String detalleC, String userN, double valorC, int meses) {
        cedula = c;
        detalleCompra = detalleC;
        userName = userN;
        valorCompra = valorC;
        mesesDiferir = meses;
        porcentajeInteres = 12;
    }

    public Consumo(String c, String detalleC, String userN, double valorC) {
        cedula = c;
        detalleCompra = detalleC;
        userName = userN;
        valorCompra = valorC;
        mesesDiferir = 6;
        porcentajeInteres = 20;
    }

    public void establecerCedula(String x) {
        cedula = x;
    }

    public void establecerDetalleCompra(String x) {
        detalleCompra = x;
    }

    public void establecerUserName(String x) {
        userName = x;
    }

    public void establecerValorCompra(double n) {
        valorCompra = n;
    }

    public void establecerMesesDiferir(int n) {
        valorCompra = n;
    }

    public void establecerPorcentajeIntereses(double n) {
        valorCompra = n;
    }

    public void calcularValorFinal() {
        valorFinal = valorCompra + (((valorCompra * porcentajeInteres) / 100) * mesesDiferir);
    }

    public String obtenerCedula() {
        return cedula;
    }

    public String obtenerDetalleCompra() {
        return detalleCompra;
    }

    public String obtenerUserName() {
        return userName;
    }

    public double obtenerValorCompra() {
        return valorCompra;
    }

    public int obtenerMesesDiferir() {
        return mesesDiferir;
    }

    public double obtenerValorFinal() {
        return valorFinal;
    }

    public double obtenerPorcentajeIntereses() {
        return porcentajeInteres;
    }

    @Override
    public String toString() {
        String cadena = String.format("""
                                      ----------------------------
                                      Consumo
                                      Cedula: %s
                                      Detalle de la Compra: %s
                                      Nombre del usuario: %s
                                      Valor de la Compra: %.2f
                                      Meses a diferir: %d
                                      Valor Final: %.2f
                                      Porcentaje de los Intereses: %.0f
                                      ----------------------------\n""",
                cedula,
                detalleCompra,
                userName,
                valorCompra,
                mesesDiferir,
                valorFinal,
                porcentajeInteres
        );
        return cadena;
    }

}
