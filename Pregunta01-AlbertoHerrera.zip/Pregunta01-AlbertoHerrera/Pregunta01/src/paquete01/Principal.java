/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete01;

import paquete02.Consumo;

/**
 *
 * @author utpl
 */
public class Principal {

    public static void main(String[] args) {

        Consumo n1 = new Consumo("1900000004", "Laptop 2024", "maria101", 1000, 3, 15);
        n1.calcularValorFinal();
        System.out.printf("%s", n1);

        Consumo n2 = new Consumo("1700020004", "Computadora Intel", "juan25", 1500, 8);
        n2.calcularValorFinal();
        System.out.printf("%s", n2);

        Consumo n3 = new Consumo("1100022004", "Tablet IPad", "axel505", 1250);
        n3.calcularValorFinal();
        System.out.printf("%s", n3);
    }
}
